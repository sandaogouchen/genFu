# bytedcli Usage In This Skill

This skill depends on `bytedcli` for internal repository and PR retrieval. Do not hand-write internal API calls when `bytedcli` can answer the question.

## Retrieval Rules

1. Start with command discovery when you do not know the exact subcommand.
2. Prefer machine-readable output when supported.
3. Use repository URL or local checkout context directly when possible.
4. Fetch broad metadata first, then deepen only the shortlist.

## Typical Flow

1. Confirm authentication and basic command surface.
2. Inspect the relevant `codebase` help entry.
3. Retrieve PR lists for the repository and date range.
4. Expand richer fields for the candidates that survive coarse filtering.

## Example Discovery Commands

```bash
bytedcli --json auth status
bytedcli codebase --help
bytedcli codebase pr --help
```

Treat these as discovery patterns, not guaranteed final commands. The command surface may evolve.

## Data To Prefer

Prefer fields that help screening:

- PR id or URL
- title
- author
- created and merged times
- labels
- reviewers
- changed files or changed directories
- PR description
- linked task or issue metadata
- test file changes

## Data To Avoid Overweighting

Do not over-index on:

- title wording alone
- one reviewer name
- merged status alone
- raw diff size without understanding scope

## Failure Handling

- If a command is unclear, inspect `--help` and adjust.
- If auth is missing, report that retrieval is blocked and stop.
- If the repository can be resolved from the local Git remote, prefer that over manually copying ids.
