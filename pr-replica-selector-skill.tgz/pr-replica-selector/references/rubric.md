# Screening Rubric

Use this file after the coarse retrieval pass. Score each dimension from 1 to 5, where 5 is best for intern replication.

## 1. Bounded Technical Complexity

- `5`: Clear feature or bugfix with moderate difficulty and limited moving parts
- `4`: Non-trivial but still recoverable with local reasoning and normal debugging
- `3`: Some hidden complexity or multiple concepts, but still feasible with time
- `2`: Multi-layer complexity or substantial framework/platform depth required
- `1`: Architecture-heavy or deeply coupled work not suited to a junior intern

## 2. Plausible Intern Ownership

- `5`: Strong signal that one contributor could own most of the work
- `4`: Some collaboration exists, but the main implementation still appears concentrated
- `3`: Ownership is mixed or uncertain
- `2`: Significant coordination likely required
- `1`: Clearly a broad, multi-owner effort

Signals:
- Single primary author
- Focused change area
- Limited review surface
- PR description scoped as one problem, not a program of work

## 3. Dependency Weight

- `5`: Mostly self-contained within one subsystem
- `4`: Small number of understandable dependencies
- `3`: Noticeable upstream/downstream coordination
- `2`: Heavy reliance on other teams, services, or experimental platforms
- `1`: Cannot reasonably reproduce without multiple external systems

## 4. Recoverable Business Context

- `5`: The why is obvious from PR text, linked task, and code changes
- `4`: Minor domain context is needed but can be reconstructed
- `3`: Business meaning is only partly visible
- `2`: Heavy hidden context or unclear product intent
- `1`: Mostly inaccessible without insider knowledge

## 5. Diff Scope Control

- `5`: Focused files and clear implementation boundary
- `4`: A few modules, still coherent
- `3`: Broad but understandable
- `2`: Scattered across many unrelated areas
- `1`: Repository-wide or highly fragmented

## 6. Resume Explainability

- `5`: Easy to describe in one or two concrete bullets
- `4`: Story is understandable with minor unpacking
- `3`: Value exists but needs careful framing
- `2`: Hard to explain clearly
- `1`: Sounds vague or low-signal on a resume

Prefer language like:
- Added
- Built
- Improved
- Reduced
- Enabled
- Prevented

Penalize PRs whose likely explanation collapses to:
- Refactored
- Adjusted
- Aligned
- Synced
- Cleaned up

## 7. Demonstrable Result

- `5`: Clear before/after effect, user-visible result, or measurable output
- `4`: Verification path is visible through tests or screenshots
- `3`: Result exists but is indirect
- `2`: Mostly invisible plumbing
- `1`: Hard to demonstrate at all

## 8. Environment Attainability

- `5`: Can likely be reproduced with local code and ordinary repo setup
- `4`: Requires some internal context but still realistic
- `3`: Setup is somewhat fragile or permissions are unclear
- `2`: Likely blocked on private data or privileged systems
- `1`: Reproduction is unrealistic for an intern environment

## Recommended Interpretation

- `34-40`: Strong candidate
- `27-33`: Worth considering
- `20-26`: Borderline, keep only if the story is unusually strong
- `<20`: Reject

## Automatic Penalties

Reduce confidence or demote rank when any of these appear:

- The PR body is too thin to support reliable judgment
- Changed files suggest coordination across many domains
- The strongest value depends on online systems the user cannot access
- The user could only reproduce a toy simulation rather than the real requirement

## Confidence Levels

- `High`: Judgment is supported by PR body, files, tests, and ownership clues
- `Medium`: Judgment is supported by several signals, but some fields are missing
- `Low`: Judgment relies on partial evidence or title-heavy inference
