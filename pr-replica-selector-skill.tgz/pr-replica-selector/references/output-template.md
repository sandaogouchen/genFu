# Ranked Output Template

Use this structure for the final answer. Keep the list ranked from strongest to weakest candidate.

## Summary

- Repository:
- Time range:
- Total PRs scanned:
- Deep-reviewed candidates:
- Strong candidates:
- Borderline candidates:
- Rejected quickly:

## Top Candidates

### 1. `[PR-ID]` PR title

- Overall fit: `Strong candidate | Worth considering | Borderline | Reject`
- Resume fit: `Strong | Medium | Weak`
- Confidence: `High | Medium | Low`
- Scores: `complexity / ownership / dependency / context / scope / resume / demo / environment`
- Why it fits:
- Main risks:
- Evidence:

Repeat for each candidate.

## Discard Summary

- Excluded for heavy coordination:
- Excluded for environment or permission blockers:
- Excluded for weak resume story:
- Excluded for hidden business context:
- Excluded for infra-only or mechanical work:

## Notes

- Call out any major uncertainty in the retrieval data.
- If the batch is very large, mention that the shortlist received deeper inspection than the rejected pool.
