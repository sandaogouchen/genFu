---
name: pr-replica-selector
description: Bulk-screen historical pull requests in ByteDance internal repositories and rank which ones are good replication targets for a junior developer intern. Use when Codex needs to review many historical PRs from internal repos, judge whether an intern could plausibly reproduce most of the work, and decide whether the result would be strong enough to discuss on a resume.
---

# Pr Replica Selector

## Overview

Find historical PRs worth replicating, not just interesting PRs. Use `bytedcli` to retrieve candidate PRs, discard poor fits early, then score the remainder against intern-feasibility and resume-value criteria.

## Workflow

1. Confirm the repository scope, time range, and desired batch size.
2. Use `bytedcli` to discover the right Codebase commands and fetch a broad PR candidate set.
3. Run a metadata pass to discard obviously unsuitable PRs.
4. Fetch richer details only for promising candidates.
5. Score the shortlist with the rubric in [references/rubric.md](references/rubric.md).
6. Return a ranked list using [references/output-template.md](references/output-template.md).

## Required Tooling

- Always route internal repository access through the `bytedcli` skill at `/Users/bytedance/.agents/skills/bytedcli/SKILL.md`.
- Prefer `bytedcli --json ...` when the command supports it.
- Do not guess internal APIs or scrape internal web pages when `bytedcli` can provide the data.
- If the correct command is unclear, inspect `--help` first and discover the right command path before running retrieval.

Read [references/bytedcli-usage.md](references/bytedcli-usage.md) when you need a lightweight reminder of how to retrieve PR data safely in this workflow.

## Inputs

- Repository URL, repo identifier, or local checkout that can be resolved to a repository
- Optional time range
- Optional path scope, module scope, or keyword scope
- Optional batch size
- Optional preference such as "more frontend", "more product-facing", or "avoid infra-heavy work"

## Retrieval Strategy

For large batches, separate retrieval into two passes:

1. Coarse pass
   Gather enough PRs to rank later. Prefer lightweight fields first: title, author, timestamps, labels, changed paths, summary text, and linked task metadata if available.
2. Deep pass
   Expand only the promising slice. Pull richer signals such as PR description, commit distribution, test changes, reviewers, affected directories, and linked issue context.

Do not spend deep-inspection time on every PR in a large result set. Use the coarse pass to eliminate weak candidates quickly.

## Evidence Discipline

- Do not judge from the title alone.
- Prefer evidence from the PR body, changed files, test changes, labels, reviewers, and linked tasks.
- Treat inferred ownership carefully. A single author is a positive signal, not proof of solo ownership.
- If evidence is thin, say so explicitly and lower confidence.

## Hard Exclusions

Discard PRs that strongly match one or more of these patterns:

- Cross-system or cross-team coordination work where intern ownership is unlikely
- PRs blocked on heavy online permissions, private datasets, or privileged environments
- Emergency incident patches whose value depends on one-off context
- Pure config churn, migration plumbing, or mechanical refactors with weak demo value
- Architecture or platform changes that clearly require senior-level context
- Changes whose business meaning is too implicit to recover from the artifact trail
- PRs where the likely replication target would be mostly mock work with little transferable value

## Scoring Standard

After exclusions, score each remaining PR on the rubric in [references/rubric.md](references/rubric.md):

- Bounded technical complexity
- Plausible intern ownership
- Dependency weight
- Recoverable business context
- Diff scope control
- Resume explainability
- Demonstrable result
- Environment attainability

When trade-offs exist, optimize for:

- A PR that an intern could realistically rebuild end to end
- A result that is easy to explain in one to three resume bullets
- A feature or improvement with visible before/after impact
- A task that does not require unrecoverable business lore

## Resume Lens

Prefer PRs that support a clean story:

- What problem existed
- What was changed
- Why the change mattered
- How success could be verified

Penalize PRs that would sound vague on a resume:

- "Optimized some internal logic"
- "Refactored multiple modules"
- "Adjusted configs and fixed issues"

Even technically sound PRs are weak candidates if their story is too fuzzy to explain in interviews.

## Batch Output

Return a ranked candidate list instead of a free-form narrative. Use the structure in [references/output-template.md](references/output-template.md).

For each accepted candidate include:

- PR identifier, title, and repository handle
- Overall fit rating
- Dimension scores
- Short evidence-based rationale
- Major replication risks
- Resume suitability judgment
- Confidence level

Also include a short discard summary for rejected patterns so the user can see what kinds of PRs were intentionally filtered out.

## Tie-Breakers

When two PRs score similarly, prefer the one with more of these signals:

- More focused changed area
- Clearer before/after user or business value
- Better test coverage or verification clues
- Lower reliance on private systems or privileged data
- Stronger evidence that one contributor handled most of the work

## Example Requests

- "Use `pr-replica-selector` to scan `https://bits.bytedance.net/code/ad/ttam_monorepo` and rank 20 PRs from the last 6 months that a junior intern could reasonably replicate."
- "Use `pr-replica-selector` to find backend-heavy PRs in this internal repo, exclude infra and emergency fixes, and return the top 10 resume-friendly candidates."
